 <section class="content-header">
      <h1>
        Registration List
       
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo ADMIN_WEBSITE_URL;?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Registration List</li>
      </ol>
    </section>
	<section class="content">
		<div class="row">
		<?php include('list.php'); ?>
		</div>
	</section>