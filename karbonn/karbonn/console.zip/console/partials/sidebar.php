 <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel Removed-->
      
      <!-- search form Removed-->
      
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
	   <li class="header">Navigation</li>
        <li class="active">
          <a href="pages/widgets.html">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
           
          </a>
         
        </li>
        
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
