<?php
/*define("WEBSITE_URL","http://localhost/lp/smarantee");
define("ADMIN_WEBSITE_URL","http://localhost/lp/admin");*/

define("ADMIN_WEBSITE_URL","http://www.sspadvantage.com/karbonn/console");